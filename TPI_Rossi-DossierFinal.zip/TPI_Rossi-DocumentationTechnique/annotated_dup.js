var annotated_dup =
[
    [ "BioLocal", "namespace_bio_local.html", [
      [ "Controller", "class_bio_local_1_1_controller.html", "class_bio_local_1_1_controller" ],
      [ "Login", "class_bio_local_1_1_login.html", "class_bio_local_1_1_login" ],
      [ "Register", "class_bio_local_1_1_register.html", "class_bio_local_1_1_register" ],
      [ "Account", "class_bio_local_1_1_account.html", "class_bio_local_1_1_account" ],
      [ "Cart", "class_bio_local_1_1_cart.html", "class_bio_local_1_1_cart" ],
      [ "DBConnection", "class_bio_local_1_1_d_b_connection.html", "class_bio_local_1_1_d_b_connection" ],
      [ "Order", "class_bio_local_1_1_order.html", "class_bio_local_1_1_order" ],
      [ "Product", "class_bio_local_1_1_product.html", "class_bio_local_1_1_product" ],
      [ "Supplyer", "class_bio_local_1_1_supplyer.html", "class_bio_local_1_1_supplyer" ]
    ] ],
    [ "BioLocalUI", "namespace_bio_local_u_i.html", [
      [ "Navbar", "class_bio_local_u_i_1_1_navbar.html", "class_bio_local_u_i_1_1_navbar" ],
      [ "Page", "class_bio_local_u_i_1_1_page.html", "class_bio_local_u_i_1_1_page" ]
    ] ],
    [ "authenticationException", "classauthentication_exception.html", "classauthentication_exception" ],
    [ "loginError", "classlogin_error.html", "classlogin_error" ],
    [ "registerError", "classregister_error.html", "classregister_error" ]
];