var class_bio_local_1_1_login =
[
    [ "isLoginCorrect", "class_bio_local_1_1_login.html#a66e0d4a3644119fcb8c26eab889fcdc9", null ],
    [ "loginAccount", "class_bio_local_1_1_login.html#ade9772c6dcbd8753d40127083ca2f174", null ]
];