var class_bio_local_1_1_product =
[
    [ "__construct", "class_bio_local_1_1_product.html#af8024c07e4a48849814fca31e0635c86", null ],
    [ "$name", "class_bio_local_1_1_product.html#a58551b63ba97fb35b928f11f36b1fac6", null ],
    [ "$price", "class_bio_local_1_1_product.html#a7a9d1970565bbae97aa0d101a4325cd3", null ],
    [ "$productID", "class_bio_local_1_1_product.html#ad71f305a32cc2a2db991aac389d7168d", null ],
    [ "$stock", "class_bio_local_1_1_product.html#a2dad33473d0f40332d33b033b5f6b736", null ],
    [ "$supplyerID", "class_bio_local_1_1_product.html#abe0e619516f96e1af7950501b785bb5b", null ]
];