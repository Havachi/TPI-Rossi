var class_bio_local_1_1_supplyer =
[
    [ "__construct", "class_bio_local_1_1_supplyer.html#aba9f543bc644f9b3388df9c3855ad277", null ],
    [ "$supplyerID", "class_bio_local_1_1_supplyer.html#abe0e619516f96e1af7950501b785bb5b", null ],
    [ "$supplyerName", "class_bio_local_1_1_supplyer.html#a7479892aa0ea27bc3290fdcc0d8da010", null ]
];