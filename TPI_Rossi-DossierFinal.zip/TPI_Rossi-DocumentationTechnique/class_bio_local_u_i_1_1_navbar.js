var class_bio_local_u_i_1_1_navbar =
[
    [ "__construct", "class_bio_local_u_i_1_1_navbar.html#a4e32130efb3929795bf8e8dabaefa7f5", null ],
    [ "$content", "class_bio_local_u_i_1_1_navbar.html#a43be552f5d6b48b6335bf0b4b5ef37c0", null ]
];