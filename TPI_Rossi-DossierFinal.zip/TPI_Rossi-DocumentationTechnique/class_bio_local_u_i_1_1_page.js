var class_bio_local_u_i_1_1_page =
[
    [ "__construct", "class_bio_local_u_i_1_1_page.html#a28203ae1f872bbf2cdef15a03c87f411", null ],
    [ "addNavbar", "class_bio_local_u_i_1_1_page.html#a726eb0402c99cc190044a43cf0188abf", null ],
    [ "beautifyTitle", "class_bio_local_u_i_1_1_page.html#a17e8bea173f1e21d314b76a131027197", null ],
    [ "$content", "class_bio_local_u_i_1_1_page.html#a43be552f5d6b48b6335bf0b4b5ef37c0", null ],
    [ "$data", "class_bio_local_u_i_1_1_page.html#a165bc765ae7568c8712902a65b77bf12", null ],
    [ "$navbar", "class_bio_local_u_i_1_1_page.html#a0f9b45f4cf62f21d0192b09d24ae4a28", null ],
    [ "$title", "class_bio_local_u_i_1_1_page.html#a5ef02115477cfad473df2455da5a908e", null ]
];