var classauthentication_exception =
[
    [ "__construct", "classauthentication_exception.html#a557cb34a1186389a1cbd10378f622574", null ],
    [ "__toString", "classauthentication_exception.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ]
];