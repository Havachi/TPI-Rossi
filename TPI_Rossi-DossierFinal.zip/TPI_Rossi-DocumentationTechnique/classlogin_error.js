var classlogin_error =
[
    [ "__construct", "classlogin_error.html#a557cb34a1186389a1cbd10378f622574", null ],
    [ "__toString", "classlogin_error.html#a7516ca30af0db3cdbf9a7739b48ce91d", null ]
];