var dir_24a1a3de56f38c43fdd76ffc3b7f25a8 =
[
    [ "controller.php", "controller_8php.html", [
      [ "Controller", "class_bio_local_1_1_controller.html", "class_bio_local_1_1_controller" ]
    ] ]
];