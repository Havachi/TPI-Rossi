var dir_a4a1aeefef353a88b02bcd5a5ed7e934 =
[
    [ "productCRUD.php", "product_c_r_u_d_8php.html", "product_c_r_u_d_8php" ],
    [ "supplyerCRUD.php", "supplyer_c_r_u_d_8php.html", "supplyer_c_r_u_d_8php" ],
    [ "userCRUD.php", "user_c_r_u_d_8php.html", "user_c_r_u_d_8php" ]
];