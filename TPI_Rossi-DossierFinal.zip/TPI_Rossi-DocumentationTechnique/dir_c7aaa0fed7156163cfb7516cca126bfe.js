var dir_c7aaa0fed7156163cfb7516cca126bfe =
[
    [ "CRUD", "dir_a4a1aeefef353a88b02bcd5a5ed7e934.html", "dir_a4a1aeefef353a88b02bcd5a5ed7e934" ],
    [ "pageModels", "dir_cb9f16a039e7615496949ec6ce03de33.html", "dir_cb9f16a039e7615496949ec6ce03de33" ],
    [ "authentication.php", "authentication_8php.html", [
      [ "Login", "class_bio_local_1_1_login.html", "class_bio_local_1_1_login" ],
      [ "Register", "class_bio_local_1_1_register.html", "class_bio_local_1_1_register" ],
      [ "Account", "class_bio_local_1_1_account.html", "class_bio_local_1_1_account" ]
    ] ],
    [ "cart.class.php", "cart_8class_8php.html", [
      [ "Cart", "class_bio_local_1_1_cart.html", "class_bio_local_1_1_cart" ]
    ] ],
    [ "DBConnection.class.php", "_d_b_connection_8class_8php.html", [
      [ "DBConnection", "class_bio_local_1_1_d_b_connection.html", "class_bio_local_1_1_d_b_connection" ]
    ] ],
    [ "distanceCalculation.php", "distance_calculation_8php.html", "distance_calculation_8php" ],
    [ "exceptions.class.php", "exceptions_8class_8php.html", [
      [ "authenticationException", "classauthentication_exception.html", "classauthentication_exception" ],
      [ "loginError", "classlogin_error.html", "classlogin_error" ],
      [ "registerError", "classregister_error.html", "classregister_error" ]
    ] ],
    [ "gravatar.php", "gravatar_8php.html", "gravatar_8php" ],
    [ "order.class.php", "order_8class_8php.html", [
      [ "Order", "class_bio_local_1_1_order.html", "class_bio_local_1_1_order" ]
    ] ],
    [ "product.class.php", "product_8class_8php.html", [
      [ "Product", "class_bio_local_1_1_product.html", "class_bio_local_1_1_product" ]
    ] ],
    [ "redirect.php", "redirect_8php.html", "redirect_8php" ],
    [ "supplyer.class.php", "supplyer_8class_8php.html", [
      [ "Supplyer", "class_bio_local_1_1_supplyer.html", "class_bio_local_1_1_supplyer" ]
    ] ]
];