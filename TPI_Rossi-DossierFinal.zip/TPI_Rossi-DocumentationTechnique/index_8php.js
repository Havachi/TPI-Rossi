var index_8php =
[
    [ "$control", "index_8php.html#a61f9db75401be83a1c4584ed3fd47e0a", null ],
    [ "$request_url", "index_8php.html#a19c3bd9fab1f70616bd76b9ffac01018", null ],
    [ "else", "index_8php.html#a030bc9beaebd021d56cdad74e9778036", null ]
];