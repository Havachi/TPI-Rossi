var namespace_bio_local =
[
    [ "Controller", "class_bio_local_1_1_controller.html", "class_bio_local_1_1_controller" ],
    [ "Login", "class_bio_local_1_1_login.html", "class_bio_local_1_1_login" ],
    [ "Register", "class_bio_local_1_1_register.html", "class_bio_local_1_1_register" ],
    [ "Account", "class_bio_local_1_1_account.html", "class_bio_local_1_1_account" ],
    [ "Cart", "class_bio_local_1_1_cart.html", "class_bio_local_1_1_cart" ],
    [ "DBConnection", "class_bio_local_1_1_d_b_connection.html", "class_bio_local_1_1_d_b_connection" ],
    [ "Order", "class_bio_local_1_1_order.html", "class_bio_local_1_1_order" ],
    [ "Product", "class_bio_local_1_1_product.html", "class_bio_local_1_1_product" ],
    [ "Supplyer", "class_bio_local_1_1_supplyer.html", "class_bio_local_1_1_supplyer" ],
    [ "addProduct", "namespace_bio_local.html#a73e4072106e457c3220e3bc7bed2d4c5", null ],
    [ "getProductById", "namespace_bio_local.html#af510bba1edcec77bd1e6586aaa53f3a9", null ],
    [ "getProductsList", "namespace_bio_local.html#a6eb6a38ea9d9d4b73e409032197ce52f", null ],
    [ "postRedirect", "namespace_bio_local.html#a355a31377f08a02c7fd48513d7ea1d1d", null ],
    [ "removeProduct", "namespace_bio_local.html#a6e23052ec1ece85022e9254bf47a0bcf", null ],
    [ "updateProduct", "namespace_bio_local.html#aea93e3c85d7c98909bf6ee8273acab67", null ],
    [ "$control", "namespace_bio_local.html#a61f9db75401be83a1c4584ed3fd47e0a", null ],
    [ "$request_url", "namespace_bio_local.html#a19c3bd9fab1f70616bd76b9ffac01018", null ],
    [ "else", "namespace_bio_local.html#a030bc9beaebd021d56cdad74e9778036", null ]
];