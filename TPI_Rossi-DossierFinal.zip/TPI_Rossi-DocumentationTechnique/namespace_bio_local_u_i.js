var namespace_bio_local_u_i =
[
    [ "Navbar", "class_bio_local_u_i_1_1_navbar.html", "class_bio_local_u_i_1_1_navbar" ],
    [ "Page", "class_bio_local_u_i_1_1_page.html", "class_bio_local_u_i_1_1_page" ]
];