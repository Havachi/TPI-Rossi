var namespaces_dup =
[
    [ "BioLocal", "namespace_bio_local.html", "namespace_bio_local" ],
    [ "BioLocalUI", "namespace_bio_local_u_i.html", "namespace_bio_local_u_i" ]
];