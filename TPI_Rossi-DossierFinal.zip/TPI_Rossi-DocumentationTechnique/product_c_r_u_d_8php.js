var product_c_r_u_d_8php =
[
    [ "addProduct", "product_c_r_u_d_8php.html#a73e4072106e457c3220e3bc7bed2d4c5", null ],
    [ "getProductById", "product_c_r_u_d_8php.html#af510bba1edcec77bd1e6586aaa53f3a9", null ],
    [ "getProductsList", "product_c_r_u_d_8php.html#a6eb6a38ea9d9d4b73e409032197ce52f", null ],
    [ "removeProduct", "product_c_r_u_d_8php.html#a6e23052ec1ece85022e9254bf47a0bcf", null ],
    [ "updateProduct", "product_c_r_u_d_8php.html#aea93e3c85d7c98909bf6ee8273acab67", null ]
];