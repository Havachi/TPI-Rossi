var searchData=
[
  ['index_2ephp_92',['index.php',['../index_8php.html',1,'']]],
  ['init_93',['Init',['../class_bio_local_1_1_d_b_connection.html#a3053a00679bcd7ad9145970d28baf429',1,'BioLocal::DBConnection']]],
  ['islogincorrect_94',['isLoginCorrect',['../class_bio_local_1_1_login.html#a66e0d4a3644119fcb8c26eab889fcdc9',1,'BioLocal::Login']]]
];
