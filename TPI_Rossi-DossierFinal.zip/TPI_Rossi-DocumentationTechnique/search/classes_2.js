var searchData=
[
  ['dbconnection_149',['DBConnection',['../class_bio_local_1_1_d_b_connection.html',1,'BioLocal']]]
];
