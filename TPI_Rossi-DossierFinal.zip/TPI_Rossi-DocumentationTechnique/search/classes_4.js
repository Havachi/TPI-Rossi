var searchData=
[
  ['navbar_152',['Navbar',['../class_bio_local_u_i_1_1_navbar.html',1,'BioLocalUI']]]
];
