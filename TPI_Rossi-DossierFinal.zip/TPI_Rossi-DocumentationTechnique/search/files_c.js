var searchData=
[
  ['settings_2eini_2ephp_188',['settings.ini.php',['../settings_8ini_8php.html',1,'']]],
  ['supplyer_2eclass_2ephp_189',['supplyer.class.php',['../supplyer_8class_8php.html',1,'']]],
  ['supplyercrud_2ephp_190',['supplyerCRUD.php',['../supplyer_c_r_u_d_8php.html',1,'']]]
];
