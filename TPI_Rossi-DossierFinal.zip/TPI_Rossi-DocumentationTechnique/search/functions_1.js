var searchData=
[
  ['addnavbar_196',['addNavbar',['../class_bio_local_u_i_1_1_page.html#a726eb0402c99cc190044a43cf0188abf',1,'BioLocalUI::Page']]],
  ['addproduct_197',['addProduct',['../namespace_bio_local.html#a73e4072106e457c3220e3bc7bed2d4c5',1,'BioLocal']]],
  ['addtocart_198',['addToCart',['../class_bio_local_1_1_cart.html#a93d6965e5440ec38573a1509eb456d72',1,'BioLocal::Cart']]]
];
