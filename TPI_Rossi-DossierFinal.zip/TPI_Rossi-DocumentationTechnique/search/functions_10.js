var searchData=
[
  ['writeorder_242',['writeOrder',['../class_bio_local_1_1_order.html#ad30affcb3129eca590d532c15985235c',1,'BioLocal::Order']]],
  ['writeproductsorder_243',['writeProductsOrder',['../class_bio_local_1_1_order.html#a4da1cb94f69bf6b9f8951489551bcdf3',1,'BioLocal::Order']]]
];
