var searchData=
[
  ['get_5fgravatar_212',['get_gravatar',['../gravatar_8php.html#a5682f77101c0f732439f2666423e9d74',1,'gravatar.php']]],
  ['getnearbypostalcode_213',['getNearbyPostalCode',['../distance_calculation_8php.html#a06fd8064f68c5ff4ef37a6648a0176fa',1,'distanceCalculation.php']]],
  ['getpagecontent_214',['getPageContent',['../class_bio_local_1_1_controller.html#a320c707ee136de38ab4bf5fd9ac16848',1,'BioLocal::Controller']]],
  ['getpagedata_215',['getPageData',['../class_bio_local_1_1_controller.html#a0e8da3a213731096a0b0152a6dd1c77a',1,'BioLocal::Controller']]],
  ['getproductbyid_216',['getProductById',['../namespace_bio_local.html#af510bba1edcec77bd1e6586aaa53f3a9',1,'BioLocal']]],
  ['getproductslist_217',['getProductsList',['../namespace_bio_local.html#a6eb6a38ea9d9d4b73e409032197ce52f',1,'BioLocal']]],
  ['getsupplyerslist_218',['getSupplyersList',['../supplyer_c_r_u_d_8php.html#aab5ca5d4a1f53918bc1e3ccf5c168107',1,'supplyerCRUD.php']]],
  ['getuserid_219',['getUserID',['../class_bio_local_1_1_account.html#a0aa76e950df1e9828e758d74d2461d90',1,'BioLocal::Account']]],
  ['getuserorderslist_220',['getUserOrdersList',['../user_c_r_u_d_8php.html#a5e2da9cf4a24f17f2cfbb9d304cb322e',1,'userCRUD.php']]]
];
