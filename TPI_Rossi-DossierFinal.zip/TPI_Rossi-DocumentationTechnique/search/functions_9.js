var searchData=
[
  ['openconnection_230',['openConnection',['../class_bio_local_1_1_d_b_connection.html#ac6137b37e757fbfd0bff06220b249303',1,'BioLocal::DBConnection']]]
];
