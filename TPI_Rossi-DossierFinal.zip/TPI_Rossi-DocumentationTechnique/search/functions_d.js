var searchData=
[
  ['single_238',['single',['../class_bio_local_1_1_d_b_connection.html#abdde5ce281efc6c7f41fd9c018886129',1,'BioLocal::DBConnection']]]
];
