var indexSectionsWithContent =
{
  0: "$_abcdeghilnopqrsuvw",
  1: "acdlnoprs",
  2: "b",
  3: "acdeghilnoprsu",
  4: "_abcdghilopqrsuvw",
  5: "$_er",
  6: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

