var searchData=
[
  ['return_288',['return',['../settings_8ini_8php.html#a9717e7bbecb906637e86cef6da3d83c2',1,'settings.ini.php']]]
];
