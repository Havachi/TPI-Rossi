var settings_8ini_8php =
[
    [ "return", "settings_8ini_8php.html#a9717e7bbecb906637e86cef6da3d83c2", null ]
];