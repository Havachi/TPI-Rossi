var supplyer_c_r_u_d_8php =
[
    [ "getSupplyersList", "supplyer_c_r_u_d_8php.html#aab5ca5d4a1f53918bc1e3ccf5c168107", null ]
];