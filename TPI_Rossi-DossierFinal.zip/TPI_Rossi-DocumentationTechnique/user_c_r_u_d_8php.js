var user_c_r_u_d_8php =
[
    [ "getUserOrdersList", "user_c_r_u_d_8php.html#a5e2da9cf4a24f17f2cfbb9d304cb322e", null ]
];